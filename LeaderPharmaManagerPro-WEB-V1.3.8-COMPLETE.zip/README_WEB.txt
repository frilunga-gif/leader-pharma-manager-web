LEADER PHARMA MANAGER PRO — VERSION WEB V1.3.8

Version Web complète basée sur la V1.3.8 validée.

Fonctions principales :
- Tableau de bord Direction
- Ventes / factures
- Impression navigateur
- Stock / lots / péremptions
- Prix détail et prix gros
- Achats / fournisseurs
- Inventaires
- Transferts inter-agences
- Clients / ordonnances
- Dépenses / trésorerie / comptabilité
- Créances / dettes
- RH / pointage / paie
- Rapports de caisse
- Analyses avancées
- Alertes
- Utilisateurs / rôles
- Audit / surveillance
- Sauvegarde et restauration JSON
- Synchronisation Supabase
- Fusion stock local + Supabase sans suppression du stock local
- Mode PWA installable et cache hors-ligne

Connexion initiale :
Utilisateur : admin
Mot de passe : admin123

IMPORTANT :
La clé Supabase incluse est une clé publique anon destinée au navigateur.
Ne jamais intégrer une clé service_role dans cette version Web.
